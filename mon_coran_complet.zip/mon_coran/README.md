# Mon Coran — projet complet (étapes 1 à 8)

Application Flutter Android + espace administrateur web + schéma Supabase.
**Ce code n'a pas été compilé ni testé par son auteur** : le premier build peut révéler de petites erreurs à corriger.

## Contenu
```
lib/                 application Flutter (thème, navigation, accueil, bibliothèque, lecteur,
                     favoris, téléchargements, import MP3, réglages, synchronisation Supabase)
tools/patch_android.py   ajoute permissions, service audio et MainActivity après `flutter create`
supabase/schema.sql      tables, index, RLS, buckets, 114 sourates
admin/index.html         espace administrateur (page web unique)
.github/workflows/       build.yml (APK) et pages.yml (hébergement de l'admin)
```

## 1. Supabase (site web, compte gratuit)
1. https://supabase.com → New project.
2. **SQL Editor** → collez tout `supabase/schema.sql` → Run.
3. **Authentication → Users → Add user** : e-mail + mot de passe (cochez « Auto confirm »).
4. **Authentication → Sign In / Providers → Email** : désactivez « Allow new users to sign up » (pas d'inscription publique).
5. SQL Editor :
   `insert into public.admins (user_id) select id from auth.users where email = 'votre@email.com';`
6. **Project Settings → API** : notez *Project URL* et la clé **anon / publishable**.
   N'utilisez JAMAIS la clé `service_role` dans l'app ou l'admin.
7. Limite gratuite : 50 Mo par fichier envoyé. Les buckets sont publics en lecture (URL non devinables).

## 2. GitHub : compiler l'APK
1. Créez un dépôt, envoyez-y tout le contenu (y compris `.github`).
2. Dépôt → **Settings → Secrets and variables → Actions → New repository secret** :
   `SUPABASE_URL` et `SUPABASE_ANON_KEY` (valeurs de l'étape 6).
3. Onglet **Actions → Build APK → Run workflow**.
4. Téléchargez l'artefact `mon-coran-apk` → installez `app-release.apk` (autorisez les sources inconnues).
Sans secrets, l'app fonctionne en mode import local uniquement.

## 3. Espace administrateur
- Dépôt → **Settings → Pages → Source : GitHub Actions**, puis lancez « Deploy admin ».
  L'adresse sera `https://VOTRE-COMPTE.github.io/NOM-DU-DEPOT/`.
- Ou ouvrez simplement `admin/index.html` dans un navigateur.
- Au premier lancement, saisissez l'URL Supabase et la clé anon (mémorisées dans le navigateur), puis connectez-vous.

## 4. Utilisation
- Admin : *Ajouter* → titre, récitant, sourate, MP3 (+ couverture) → cocher *Publier*.
- App : tirez l'écran vers le bas ou bouton Synchroniser → la récitation apparaît, sans nouvelle APK.
- Icône nuage/flèche : télécharger pour l'écoute hors ligne.

## 5. Compiler en local (optionnel)
1. Installez Flutter (https://docs.flutter.dev/get-started/install) et Android Studio (SDK Android + licences : `flutter doctor --android-licenses`).
2. Dans le dossier du projet :
```
flutter create --platforms=android --project-name mon_coran --org com.moncoran .
python3 tools/patch_android.py
flutter pub get
flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
flutter build apk --debug      # APK de débogage
flutter build apk --release --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
```
APK : `build/app/outputs/flutter-apk/`.

## 6. Erreurs courantes
- *Version solving failed* : relâchez la contrainte du paquet fautif dans `pubspec.yaml`, relancez `flutter pub get`.
- *minSdkVersion* : mettez `minSdk = 24` dans `android/app/build.gradle(.kts)`.
- Pas de notification de lecture : acceptez la permission de notification (Android 13+).
- Sync vide : récitation non publiée, ou URL/clé incorrecte, ou script SQL non exécuté.
- Le APK « release » est signé avec la clé de débogage : installable, mais pas publiable sur le Play Store (il faudra un keystore).

## Limites connues
- Pas de police arabe dédiée (police système). Ajoutez une police (ex. Amiri) dans `assets/fonts` + `pubspec.yaml`.
- Favoris et réglages sont stockés sur l'appareil (pas de compte utilisateur).
- Les sourates sont en saisie libre pour les imports locaux.
- Icône d'application = icône Flutter par défaut.
