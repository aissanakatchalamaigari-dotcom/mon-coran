-- =====================================================================
-- MON CORAN — schéma Supabase (à coller dans SQL Editor puis "Run")
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------- Tables ----------
create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.reciters (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  bio text,
  created_at timestamptz not null default now()
);

create table if not exists public.surahs (
  number int primary key check (number between 1 and 114),
  name_fr text not null,
  name_ar text not null
);

create table if not exists public.recitations (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  reciter_id uuid references public.reciters(id) on delete restrict,
  surah_number int references public.surahs(number),
  description text,
  audio_path text not null,          -- chemin dans le bucket "audio"
  audio_url text not null,           -- URL publique
  cover_path text,                   -- chemin dans le bucket "covers"
  cover_url text,
  duration_seconds int,
  file_size_bytes bigint,
  is_published boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- Index ----------
create index if not exists idx_recitations_published
  on public.recitations (is_published, published_at desc);
create index if not exists idx_recitations_reciter on public.recitations (reciter_id);
create index if not exists idx_recitations_surah on public.recitations (surah_number);

-- ---------- Triggers ----------
create or replace function public.touch_recitation()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  if new.is_published and new.published_at is null then
    new.published_at = now();
  end if;
  return new;
end $$;

drop trigger if exists trg_touch_recitation on public.recitations;
create trigger trg_touch_recitation
  before insert or update on public.recitations
  for each row execute function public.touch_recitation();

-- ---------- Fonction admin ----------
create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;

-- ---------- RLS ----------
alter table public.admins enable row level security;      -- aucune policy = inaccessible via l'API
alter table public.reciters enable row level security;
alter table public.surahs enable row level security;
alter table public.recitations enable row level security;

drop policy if exists "reciters_public_read" on public.reciters;
create policy "reciters_public_read" on public.reciters
  for select to anon, authenticated using (true);
drop policy if exists "reciters_admin_write" on public.reciters;
create policy "reciters_admin_write" on public.reciters
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "surahs_public_read" on public.surahs;
create policy "surahs_public_read" on public.surahs
  for select to anon, authenticated using (true);
drop policy if exists "surahs_admin_write" on public.surahs;
create policy "surahs_admin_write" on public.surahs
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "recitations_public_read" on public.recitations;
create policy "recitations_public_read" on public.recitations
  for select to anon, authenticated using (is_published = true);
drop policy if exists "recitations_admin_all" on public.recitations;
create policy "recitations_admin_all" on public.recitations
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ---------- Storage ----------
insert into storage.buckets (id, name, public)
values ('audio', 'audio', true), ('covers', 'covers', true)
on conflict (id) do nothing;

drop policy if exists "media_admin_select" on storage.objects;
create policy "media_admin_select" on storage.objects
  for select to authenticated
  using (bucket_id in ('audio','covers') and public.is_admin());
drop policy if exists "media_admin_insert" on storage.objects;
create policy "media_admin_insert" on storage.objects
  for insert to authenticated
  with check (bucket_id in ('audio','covers') and public.is_admin());
drop policy if exists "media_admin_update" on storage.objects;
create policy "media_admin_update" on storage.objects
  for update to authenticated
  using (bucket_id in ('audio','covers') and public.is_admin());
drop policy if exists "media_admin_delete" on storage.objects;
create policy "media_admin_delete" on storage.objects
  for delete to authenticated
  using (bucket_id in ('audio','covers') and public.is_admin());

-- ---------- Sourates (114) ----------
insert into public.surahs (number, name_fr, name_ar) values
  (1, 'Al-Fatiha', 'الفاتحة'),
  (2, 'Al-Baqara', 'البقرة'),
  (3, 'Al ''Imran', 'آل عمران'),
  (4, 'An-Nisa', 'النساء'),
  (5, 'Al-Ma''ida', 'المائدة'),
  (6, 'Al-An''am', 'الأنعام'),
  (7, 'Al-A''raf', 'الأعراف'),
  (8, 'Al-Anfal', 'الأنفال'),
  (9, 'At-Tawba', 'التوبة'),
  (10, 'Yunus', 'يونس'),
  (11, 'Hud', 'هود'),
  (12, 'Yusuf', 'يوسف'),
  (13, 'Ar-Ra''d', 'الرعد'),
  (14, 'Ibrahim', 'إبراهيم'),
  (15, 'Al-Hijr', 'الحجر'),
  (16, 'An-Nahl', 'النحل'),
  (17, 'Al-Isra', 'الإسراء'),
  (18, 'Al-Kahf', 'الكهف'),
  (19, 'Maryam', 'مريم'),
  (20, 'Ta-Ha', 'طه'),
  (21, 'Al-Anbiya', 'الأنبياء'),
  (22, 'Al-Hajj', 'الحج'),
  (23, 'Al-Mu''minun', 'المؤمنون'),
  (24, 'An-Nur', 'النور'),
  (25, 'Al-Furqan', 'الفرقان'),
  (26, 'Ash-Shu''ara', 'الشعراء'),
  (27, 'An-Naml', 'النمل'),
  (28, 'Al-Qasas', 'القصص'),
  (29, 'Al-''Ankabut', 'العنكبوت'),
  (30, 'Ar-Rum', 'الروم'),
  (31, 'Luqman', 'لقمان'),
  (32, 'As-Sajda', 'السجدة'),
  (33, 'Al-Ahzab', 'الأحزاب'),
  (34, 'Saba', 'سبأ'),
  (35, 'Fatir', 'فاطر'),
  (36, 'Ya-Sin', 'يس'),
  (37, 'As-Saffat', 'الصافات'),
  (38, 'Sad', 'ص'),
  (39, 'Az-Zumar', 'الزمر'),
  (40, 'Ghafir', 'غافر'),
  (41, 'Fussilat', 'فصلت'),
  (42, 'Ash-Shura', 'الشورى'),
  (43, 'Az-Zukhruf', 'الزخرف'),
  (44, 'Ad-Dukhan', 'الدخان'),
  (45, 'Al-Jathiya', 'الجاثية'),
  (46, 'Al-Ahqaf', 'الأحقاف'),
  (47, 'Muhammad', 'محمد'),
  (48, 'Al-Fath', 'الفتح'),
  (49, 'Al-Hujurat', 'الحجرات'),
  (50, 'Qaf', 'ق'),
  (51, 'Adh-Dhariyat', 'الذاريات'),
  (52, 'At-Tur', 'الطور'),
  (53, 'An-Najm', 'النجم'),
  (54, 'Al-Qamar', 'القمر'),
  (55, 'Ar-Rahman', 'الرحمن'),
  (56, 'Al-Waqi''a', 'الواقعة'),
  (57, 'Al-Hadid', 'الحديد'),
  (58, 'Al-Mujadila', 'المجادلة'),
  (59, 'Al-Hashr', 'الحشر'),
  (60, 'Al-Mumtahana', 'الممتحنة'),
  (61, 'As-Saff', 'الصف'),
  (62, 'Al-Jumu''a', 'الجمعة'),
  (63, 'Al-Munafiqun', 'المنافقون'),
  (64, 'At-Taghabun', 'التغابن'),
  (65, 'At-Talaq', 'الطلاق'),
  (66, 'At-Tahrim', 'التحريم'),
  (67, 'Al-Mulk', 'الملك'),
  (68, 'Al-Qalam', 'القلم'),
  (69, 'Al-Haqqa', 'الحاقة'),
  (70, 'Al-Ma''arij', 'المعارج'),
  (71, 'Nuh', 'نوح'),
  (72, 'Al-Jinn', 'الجن'),
  (73, 'Al-Muzzammil', 'المزمل'),
  (74, 'Al-Muddaththir', 'المدثر'),
  (75, 'Al-Qiyama', 'القيامة'),
  (76, 'Al-Insan', 'الإنسان'),
  (77, 'Al-Mursalat', 'المرسلات'),
  (78, 'An-Naba', 'النبأ'),
  (79, 'An-Nazi''at', 'النازعات'),
  (80, '''Abasa', 'عبس'),
  (81, 'At-Takwir', 'التكوير'),
  (82, 'Al-Infitar', 'الانفطار'),
  (83, 'Al-Mutaffifin', 'المطففين'),
  (84, 'Al-Inshiqaq', 'الانشقاق'),
  (85, 'Al-Buruj', 'البروج'),
  (86, 'At-Tariq', 'الطارق'),
  (87, 'Al-A''la', 'الأعلى'),
  (88, 'Al-Ghashiya', 'الغاشية'),
  (89, 'Al-Fajr', 'الفجر'),
  (90, 'Al-Balad', 'البلد'),
  (91, 'Ash-Shams', 'الشمس'),
  (92, 'Al-Layl', 'الليل'),
  (93, 'Ad-Duha', 'الضحى'),
  (94, 'Ash-Sharh', 'الشرح'),
  (95, 'At-Tin', 'التين'),
  (96, 'Al-''Alaq', 'العلق'),
  (97, 'Al-Qadr', 'القدر'),
  (98, 'Al-Bayyina', 'البينة'),
  (99, 'Az-Zalzala', 'الزلزلة'),
  (100, 'Al-''Adiyat', 'العاديات'),
  (101, 'Al-Qari''a', 'القارعة'),
  (102, 'At-Takathur', 'التكاثر'),
  (103, 'Al-''Asr', 'العصر'),
  (104, 'Al-Humaza', 'الهمزة'),
  (105, 'Al-Fil', 'الفيل'),
  (106, 'Quraysh', 'قريش'),
  (107, 'Al-Ma''un', 'الماعون'),
  (108, 'Al-Kawthar', 'الكوثر'),
  (109, 'Al-Kafirun', 'الكافرون'),
  (110, 'An-Nasr', 'النصر'),
  (111, 'Al-Masad', 'المسد'),
  (112, 'Al-Ikhlas', 'الإخلاص'),
  (113, 'Al-Falaq', 'الفلق'),
  (114, 'An-Nas', 'الناس')
on conflict (number) do nothing;

-- ---------- Premier administrateur ----------
-- 1) Dashboard Supabase > Authentication > Users > "Add user" (e-mail + mot de passe, cochez "Auto confirm").
-- 2) Désactivez les inscriptions publiques : Authentication > Sign In / Providers > Email > désactiver "Allow new users to sign up".
-- 3) Exécutez ensuite (remplacez l'e-mail) :
--
-- insert into public.admins (user_id)
-- select id from auth.users where email = 'votre@email.com';
