import re, pathlib, glob

# ---- AndroidManifest ----
mp = pathlib.Path('android/app/src/main/AndroidManifest.xml')
s = mp.read_text()

perms = '''    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
'''
if 'FOREGROUND_SERVICE_MEDIA_PLAYBACK' not in s:
    s = s.replace('<application', perms + '    <application', 1)

service = '''
        <service android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback"
            android:exported="true">
            <intent-filter>
                <action android:name="android.media.browse.MediaBrowserService"/>
            </intent-filter>
        </service>
        <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON"/>
            </intent-filter>
        </receiver>
'''
if 'com.ryanheise.audioservice.AudioService' not in s:
    s = s.replace('</application>', service + '    </application>', 1)

s = re.sub(r'android:label="[^"]*"', 'android:label="Mon Coran"', s, count=1)
mp.write_text(s)

# ---- MainActivity -> AudioServiceActivity ----
for f in glob.glob('android/app/src/main/**/MainActivity.*', recursive=True):
    p = pathlib.Path(f)
    t = p.read_text()
    m = re.search(r'^package\s+([\w.]+)', t, re.M)
    if not m:
        continue
    pkg = m.group(1)
    if f.endswith('.kt'):
        p.write_text(f'package {pkg}\n\nimport com.ryanheise.audioservice.AudioServiceActivity\n\nclass MainActivity : AudioServiceActivity()\n')
    elif f.endswith('.java'):
        p.write_text(f'package {pkg};\n\nimport com.ryanheise.audioservice.AudioServiceActivity;\n\npublic class MainActivity extends AudioServiceActivity {{\n}}\n')
    print('Patched', f)

print(mp.read_text())
