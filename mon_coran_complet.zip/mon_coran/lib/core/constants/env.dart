/// Valeurs injectées à la compilation avec --dart-define (jamais de clé secrète ici).
/// La clé "anon"/"publishable" est publique par conception : la sécurité repose sur les règles RLS.
class Env {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  static bool get hasSupabase =>
      supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;
}
