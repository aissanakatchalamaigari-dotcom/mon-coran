import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Motif géométrique islamique discret (étoile à 8 branches + cercles).
class StarPainter extends CustomPainter {
  final int alpha;
  const StarPainter({this.alpha = 170});

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..color = AppColors.lavender.withAlpha(alpha);
    canvas.drawCircle(c, r * 0.9, p);
    canvas.drawCircle(c, r * 0.42, p);
    for (var k = 0; k < 2; k++) {
      final path = Path();
      for (var j = 0; j < 4; j++) {
        final a = (k * 45 + j * 90) * math.pi / 180 - math.pi / 4;
        final pt = Offset(
            c.dx + r * 0.78 * math.cos(a), c.dy + r * 0.78 * math.sin(a));
        j == 0 ? path.moveTo(pt.dx, pt.dy) : path.lineTo(pt.dx, pt.dy);
      }
      path.close();
      canvas.drawPath(path, p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
