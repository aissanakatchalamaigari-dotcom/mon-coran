import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class GlowBackground extends StatelessWidget {
  final Widget child;
  const GlowBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const Positioned.fill(child: ColoredBox(color: AppColors.night)),
        Positioned(
          top: -140,
          right: -120,
          child: Container(
            width: 380,
            height: 380,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [
                AppColors.violet.withAlpha(90),
                AppColors.violet.withAlpha(0),
              ]),
            ),
          ),
        ),
        Positioned(
          bottom: -160,
          left: -140,
          child: Container(
            width: 360,
            height: 360,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [
                AppColors.lavender.withAlpha(40),
                AppColors.lavender.withAlpha(0),
              ]),
            ),
          ),
        ),
        child,
      ],
    );
  }
}
