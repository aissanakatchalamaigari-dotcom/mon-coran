import 'package:flutter/material.dart';

import '../../models/recitation.dart';
import '../theme/app_theme.dart';

class RecitationTile extends StatelessWidget {
  final Recitation recitation;
  final VoidCallback onTap;
  final Widget? trailing;
  const RecitationTile(
      {super.key,
      required this.recitation,
      required this.onTap,
      this.trailing});

  @override
  Widget build(BuildContext context) {
    final r = recitation;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 6, 10),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    gradient: const LinearGradient(
                        colors: [AppColors.violet, Color(0xFF5B45C9)]),
                  ),
                  child: const Icon(Icons.play_arrow_rounded,
                      color: Colors.white, size: 30),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(r.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 15)),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Icon(
                              r.isRemote
                                  ? (r.isOffline
                                      ? Icons.offline_pin_rounded
                                      : Icons.cloud_outlined)
                                  : Icons.phone_android_rounded,
                              size: 13,
                              color: AppColors.violet),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(r.subtitle,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    color: AppColors.lavender, fontSize: 12.5)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                if (trailing != null) trailing!,
              ],
            ),
          ),
        ),
      ),
    );
  }
}
