import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';

import '../../services/player_controller.dart';
import '../theme/app_theme.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final pc = context.watch<PlayerController>();
    final r = pc.current;
    if (r == null) return const SizedBox.shrink();

    return GestureDetector(
      onTap: () => context.push('/player'),
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
        padding: const EdgeInsets.fromLTRB(14, 8, 8, 8),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.violet.withAlpha(90)),
          boxShadow: [
            BoxShadow(color: AppColors.violet.withAlpha(50), blurRadius: 18),
          ],
        ),
        child: Row(
          children: [
            const Icon(Icons.graphic_eq_rounded, color: AppColors.violet),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(r.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text(r.reciter,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: AppColors.lavender, fontSize: 12)),
                ],
              ),
            ),
            StreamBuilder<PlayerState>(
              stream: pc.player.playerStateStream,
              builder: (context, snap) {
                final playing = snap.data?.playing ?? false;
                return IconButton(
                  onPressed: pc.togglePlay,
                  icon: Icon(playing
                      ? Icons.pause_circle_filled_rounded
                      : Icons.play_circle_filled_rounded),
                  iconSize: 38,
                  color: AppColors.violet,
                );
              },
            ),
            IconButton(
              onPressed: pc.stop,
              icon: const Icon(Icons.close_rounded),
              color: AppColors.lavender,
            ),
          ],
        ),
      ),
    );
  }
}
