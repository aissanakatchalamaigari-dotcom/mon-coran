import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'glow_background.dart';
import 'mini_player.dart';

class ShellScaffold extends StatelessWidget {
  final StatefulNavigationShell shell;
  const ShellScaffold({super.key, required this.shell});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GlowBackground(child: shell),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const MiniPlayer(),
          NavigationBar(
            selectedIndex: shell.currentIndex,
            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
            onDestinationSelected: (i) =>
                shell.goBranch(i, initialLocation: i == shell.currentIndex),
            destinations: const [
              NavigationDestination(
                  icon: Icon(Icons.home_outlined),
                  selectedIcon: Icon(Icons.home_rounded),
                  label: 'Accueil'),
              NavigationDestination(
                  icon: Icon(Icons.library_music_outlined),
                  selectedIcon: Icon(Icons.library_music_rounded),
                  label: 'Biblio'),
              NavigationDestination(
                  icon: Icon(Icons.favorite_border_rounded),
                  selectedIcon: Icon(Icons.favorite_rounded),
                  label: 'Favoris'),
              NavigationDestination(
                  icon: Icon(Icons.download_for_offline_outlined),
                  selectedIcon: Icon(Icons.download_for_offline_rounded),
                  label: 'Hors ligne'),
              NavigationDestination(
                  icon: Icon(Icons.settings_outlined),
                  selectedIcon: Icon(Icons.settings_rounded),
                  label: 'Réglages'),
            ],
          ),
        ],
      ),
    );
  }
}
