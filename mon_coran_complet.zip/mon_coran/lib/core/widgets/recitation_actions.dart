import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/recitation.dart';
import '../../services/favorites_controller.dart';
import '../../services/library_controller.dart';
import '../theme/app_theme.dart';

/// Favori + téléchargement (+ suppression pour les fichiers importés).
class RecitationActions extends StatelessWidget {
  final Recitation r;
  final VoidCallback? onDeleteLocal;
  const RecitationActions({super.key, required this.r, this.onDeleteLocal});

  static const _c = BoxConstraints(minWidth: 40, minHeight: 40);

  @override
  Widget build(BuildContext context) {
    final lib = context.watch<LibraryController>();
    final fav = context.watch<FavoritesController>();
    final isFav = fav.isFavorite(r.id);

    Widget second;
    if (!r.isRemote) {
      second = PopupMenuButton<String>(
        icon: const Icon(Icons.more_vert_rounded, color: AppColors.lavender),
        color: AppColors.surface,
        onSelected: (v) {
          if (v == 'delete') onDeleteLocal?.call();
        },
        itemBuilder: (_) => const [
          PopupMenuItem(value: 'delete', child: Text('Supprimer')),
        ],
      );
    } else if (lib.isDownloading(r.id)) {
      final p = lib.progressOf(r.id) ?? 0;
      second = IconButton(
        constraints: _c,
        padding: EdgeInsets.zero,
        tooltip: 'Annuler',
        onPressed: () => lib.cancelDownload(r.id),
        icon: SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(
              value: p > 0 ? p : null,
              strokeWidth: 3,
              color: AppColors.violet),
        ),
      );
    } else if (r.isOffline) {
      second = IconButton(
        constraints: _c,
        padding: EdgeInsets.zero,
        tooltip: 'Disponible hors ligne (appuyer pour supprimer)',
        onPressed: () => lib.deleteDownload(r.id),
        icon: const Icon(Icons.download_done_rounded, color: AppColors.violet),
      );
    } else if (lib.downloadErrors.containsKey(r.id)) {
      second = IconButton(
        constraints: _c,
        padding: EdgeInsets.zero,
        tooltip: 'Échec, réessayer',
        onPressed: () => lib.download(r),
        icon: const Icon(Icons.error_outline_rounded,
            color: Color(0xFFFF8A9B)),
      );
    } else {
      second = IconButton(
        constraints: _c,
        padding: EdgeInsets.zero,
        tooltip: 'Télécharger',
        onPressed: () => lib.download(r),
        icon: const Icon(Icons.download_rounded, color: AppColors.lavender),
      );
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        IconButton(
          constraints: _c,
          padding: EdgeInsets.zero,
          tooltip: 'Favori',
          onPressed: () => fav.toggle(r.id),
          icon: Icon(
              isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              color: isFav ? AppColors.violet : AppColors.lavender),
        ),
        second,
      ],
    );
  }
}
