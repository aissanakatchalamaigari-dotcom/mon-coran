import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class Waveform extends StatefulWidget {
  final bool active;
  final double height;
  const Waveform({super.key, required this.active, this.height = 56});

  @override
  State<Waveform> createState() => _WaveformState();
}

class _WaveformState extends State<Waveform>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1800));

  @override
  void initState() {
    super.initState();
    if (widget.active) _c.repeat();
  }

  @override
  void didUpdateWidget(covariant Waveform old) {
    super.didUpdateWidget(old);
    if (widget.active && !_c.isAnimating) {
      _c.repeat();
    } else if (!widget.active && _c.isAnimating) {
      _c.stop();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) => CustomPaint(
          size: Size(double.infinity, widget.height),
          painter: _WavePainter(_c.value, widget.active),
        ),
      ),
    );
  }
}

class _WavePainter extends CustomPainter {
  final double phase;
  final bool active;
  _WavePainter(this.phase, this.active);

  @override
  void paint(Canvas canvas, Size size) {
    const n = 36;
    final slot = size.width / n;
    final barW = slot * 0.55;
    final t = phase * 2 * math.pi;
    final paint = Paint()
      ..shader = const LinearGradient(
              colors: [AppColors.lavender, AppColors.violet])
          .createShader(Offset.zero & size);
    for (var i = 0; i < n; i++) {
      final v = active
          ? (math.sin(t + i * 0.55) + math.sin(t * 2 + i * 0.23)) / 4 + 0.5
          : 0.1;
      final h = math.max(4.0, size.height * (0.12 + 0.88 * v));
      final x = i * slot + (slot - barW) / 2;
      final y = (size.height - h) / 2;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(x, y, barW, h), Radius.circular(barW / 2)),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _WavePainter old) =>
      old.phase != phase || old.active != active;
}
