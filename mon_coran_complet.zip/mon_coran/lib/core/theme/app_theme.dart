import 'package:flutter/material.dart';

class AppColors {
  static const night = Color(0xFF080D24);
  static const violet = Color(0xFF987BFF);
  static const lavender = Color(0xFFC4B8FF);
  static const soft = Color(0xFFF5F5FF);
  static const surface = Color(0xFF151B39);
}

ThemeData buildAppTheme() {
  final base = ThemeData(brightness: Brightness.dark, useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: AppColors.night,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.violet,
      onPrimary: AppColors.night,
      secondary: AppColors.lavender,
      surface: AppColors.surface,
      onSurface: AppColors.soft,
    ),
    textTheme: base.textTheme.apply(
      bodyColor: AppColors.soft,
      displayColor: AppColors.soft,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: AppColors.surface,
      indicatorColor: AppColors.violet.withAlpha(70),
      labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
    ),
    sliderTheme: base.sliderTheme.copyWith(
      activeTrackColor: AppColors.violet,
      inactiveTrackColor: AppColors.lavender.withAlpha(50),
      thumbColor: AppColors.lavender,
      trackHeight: 4,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.surface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}
