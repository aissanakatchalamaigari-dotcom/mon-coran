import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app.dart';
import 'core/constants/env.dart';
import 'services/favorites_controller.dart';
import 'services/library_controller.dart';
import 'services/player_controller.dart';
import 'services/settings_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF151B39),
  ));

  try {
    await JustAudioBackground.init(
      androidNotificationChannelId: 'com.moncoran.audio',
      androidNotificationChannelName: 'Mon Coran',
      androidNotificationOngoing: true,
    );
  } catch (e) {
    debugPrint('JustAudioBackground init: $e');
  }

  if (Env.hasSupabase) {
    try {
      await Supabase.initialize(
          url: Env.supabaseUrl, anonKey: Env.supabaseAnonKey);
    } catch (e) {
      debugPrint('Supabase init: $e');
    }
  }

  final settings = SettingsController();
  await settings.load();

  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(value: settings),
      ChangeNotifierProvider(create: (_) => LibraryController()..load()),
      ChangeNotifierProvider(create: (_) => FavoritesController()..load()),
      ChangeNotifierProvider(create: (_) => PlayerController(settings)),
    ],
    child: const MonCoranApp(),
  ));
}
