import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/recitation.dart';
import 'remote_service.dart';

/// Catalogue (imports locaux + récitations Supabase en cache) et téléchargements hors ligne.
class LibraryController extends ChangeNotifier {
  static const _kLocal = 'local_v2';
  static const _kRemote = 'remote_v1';
  static const _kDownloads = 'downloads_v1';
  static const _kLastSync = 'last_sync_v1';

  final List<Recitation> _local = [];
  List<Recitation> _remote = [];
  final Map<String, String> _downloads = {};
  final Map<String, int> _sizes = {};
  final Map<String, double> _progress = {};
  final Map<String, String> _dlErrors = {};
  final Map<String, http.Client> _clients = {};
  final Set<String> _cancelled = {};

  bool loading = true;
  bool syncing = false;
  String? syncError;
  DateTime? lastSync;
  String query = '';

  // ---------- lecture ----------
  List<Recitation> get items {
    final all = <Recitation>[
      ..._remote.map((r) => r.copyWith(localPath: _downloads[r.id])),
      ..._local,
    ];
    all.sort((a, b) => b.addedAt.compareTo(a.addedAt));
    return all;
  }

  List<Recitation> get downloadedItems =>
      items.where((r) => r.isRemote && r.isOffline).toList();

  List<String> get activeDownloadIds => _progress.keys.toList();
  Map<String, String> get downloadErrors => Map.unmodifiable(_dlErrors);
  double? progressOf(String id) => _progress[id];
  bool isDownloading(String id) => _progress.containsKey(id);
  int sizeOf(String id) => _sizes[id] ?? 0;
  int get downloadsBytes => _sizes.values.fold(0, (a, b) => a + b);

  void setQuery(String q) {
    query = q;
    notifyListeners();
  }

  // ---------- chargement ----------
  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    try {
      final raw = prefs.getStringList(_kLocal) ?? [];
      _local
        ..clear()
        ..addAll(raw.map((s) =>
            Recitation.fromJson(jsonDecode(s) as Map<String, dynamic>)));
    } catch (e) {
      debugPrint('load local: $e');
    }
    try {
      final s = prefs.getString(_kRemote);
      if (s != null) {
        _remote = (jsonDecode(s) as List)
            .map((e) => Recitation.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
      }
    } catch (e) {
      debugPrint('load remote cache: $e');
    }
    try {
      final s = prefs.getString(_kDownloads);
      if (s != null) {
        final m = jsonDecode(s) as Map<String, dynamic>;
        for (final e in m.entries) {
          final f = File(e.value as String);
          if (await f.exists()) {
            _downloads[e.key] = e.value as String;
            _sizes[e.key] = await f.length();
          }
        }
      }
    } catch (e) {
      debugPrint('load downloads: $e');
    }
    final ls = prefs.getString(_kLastSync);
    lastSync = ls == null ? null : DateTime.tryParse(ls);
    loading = false;
    notifyListeners();
    if (RemoteService.enabled) unawaited(sync());
  }

  Future<void> _saveLocal() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
        _kLocal, _local.map((r) => jsonEncode(r.toJson())).toList());
  }

  Future<void> _saveRemote() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _kRemote, jsonEncode(_remote.map((r) => r.toJson()).toList()));
    if (lastSync != null) {
      await prefs.setString(_kLastSync, lastSync!.toIso8601String());
    }
  }

  Future<void> _saveDownloads() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kDownloads, jsonEncode(_downloads));
  }

  // ---------- synchronisation Supabase ----------
  Future<void> sync() async {
    if (!RemoteService.enabled || syncing) return;
    syncing = true;
    syncError = null;
    notifyListeners();
    try {
      final fetched = await RemoteService.fetchPublished();
      _remote = fetched;
      lastSync = DateTime.now();
      await _saveRemote();
      final ids = fetched.map((e) => e.id).toSet();
      for (final id
          in _downloads.keys.where((k) => !ids.contains(k)).toList()) {
        await _deleteDownloadFile(id);
      }
      await _saveDownloads();
    } catch (e) {
      debugPrint('sync: $e');
      syncError = 'Synchronisation impossible. Vérifiez votre connexion.';
    }
    syncing = false;
    notifyListeners();
  }

  // ---------- import local ----------
  Future<Recitation> importFile({
    required String sourcePath,
    required String originalName,
    required String title,
    required String reciter,
    required String surah,
    String description = '',
  }) async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}/audio');
    if (!await dir.exists()) await dir.create(recursive: true);

    final stamp = DateTime.now().millisecondsSinceEpoch;
    final dot = originalName.lastIndexOf('.');
    final ext = dot >= 0 ? originalName.substring(dot) : '.mp3';
    final dest = '${dir.path}/$stamp$ext';
    await File(sourcePath).copy(dest);

    final r = Recitation(
      id: 'local_$stamp',
      title: title,
      reciter: reciter,
      surah: surah,
      description: description,
      source: RecitationSource.local,
      localPath: dest,
      sizeBytes: await File(dest).length(),
      addedAt: DateTime.now(),
    );
    _local.insert(0, r);
    await _saveLocal();
    notifyListeners();
    return r;
  }

  Future<void> removeLocal(String id) async {
    final idx = _local.indexWhere((r) => r.id == id);
    if (idx < 0) return;
    final r = _local.removeAt(idx);
    await _tryDelete(r.localPath);
    await _saveLocal();
    notifyListeners();
  }

  Future<void> clearLocal() async {
    for (final r in _local) {
      await _tryDelete(r.localPath);
    }
    _local.clear();
    await _saveLocal();
    notifyListeners();
  }

  Future<int> importedBytes() async {
    var total = 0;
    for (final r in _local) {
      final p = r.localPath;
      if (p == null) continue;
      final f = File(p);
      if (await f.exists()) total += await f.length();
    }
    return total;
  }

  // ---------- téléchargements ----------
  Future<void> download(Recitation r) async {
    final url = r.remoteUrl;
    if (url == null || _progress.containsKey(r.id) || _downloads.containsKey(r.id)) {
      return;
    }
    _dlErrors.remove(r.id);
    _cancelled.remove(r.id);
    final client = http.Client();
    _clients[r.id] = client;
    _progress[r.id] = 0;
    notifyListeners();

    File? file;
    IOSink? sink;
    try {
      final resp = await client.send(http.Request('GET', Uri.parse(url)));
      if (resp.statusCode != 200) throw 'HTTP ${resp.statusCode}';
      final total = resp.contentLength ?? r.sizeBytes ?? 0;

      final docs = await getApplicationDocumentsDirectory();
      final dir = Directory('${docs.path}/downloads');
      if (!await dir.exists()) await dir.create(recursive: true);
      final path = Uri.parse(url).path;
      final dot = path.lastIndexOf('.');
      var ext = dot >= 0 ? path.substring(dot) : '.mp3';
      if (ext.length > 6) ext = '.mp3';
      file = File('${dir.path}/${r.id}$ext');
      sink = file.openWrite();

      var got = 0;
      var lastNotified = 0.0;
      await for (final chunk in resp.stream) {
        sink.add(chunk);
        got += chunk.length;
        if (total > 0) {
          final p = got / total;
          if (p - lastNotified >= 0.01) {
            lastNotified = p;
            _progress[r.id] = p > 1 ? 1 : p;
            notifyListeners();
          }
        }
      }
      await sink.flush();
      await sink.close();
      sink = null;
      _downloads[r.id] = file.path;
      _sizes[r.id] = got;
      await _saveDownloads();
    } catch (e) {
      try {
        await sink?.close();
      } catch (_) {}
      await _tryDelete(file?.path);
      if (!_cancelled.contains(r.id)) {
        debugPrint('download: $e');
        _dlErrors[r.id] = 'Téléchargement impossible : $e';
      }
    } finally {
      client.close();
      _clients.remove(r.id);
      _progress.remove(r.id);
      _cancelled.remove(r.id);
      notifyListeners();
    }
  }

  void cancelDownload(String id) {
    _cancelled.add(id);
    _clients[id]?.close();
  }

  void clearDownloadError(String id) {
    _dlErrors.remove(id);
    notifyListeners();
  }

  Future<void> deleteDownload(String id) async {
    await _deleteDownloadFile(id);
    await _saveDownloads();
    notifyListeners();
  }

  Future<void> clearDownloads() async {
    for (final id in _downloads.keys.toList()) {
      await _deleteDownloadFile(id);
    }
    await _saveDownloads();
    notifyListeners();
  }

  Future<void> _deleteDownloadFile(String id) async {
    await _tryDelete(_downloads[id]);
    _downloads.remove(id);
    _sizes.remove(id);
  }

  Future<void> _tryDelete(String? path) async {
    if (path == null) return;
    try {
      final f = File(path);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }
}
