import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/constants/env.dart';
import '../models/recitation.dart';

/// Lecture seule des récitations publiées (la clé anon + RLS suffisent).
class RemoteService {
  static bool get enabled => Env.hasSupabase;

  static Future<List<Recitation>> fetchPublished() async {
    final client = Supabase.instance.client;
    final rows = await client
        .from('recitations')
        .select('id,title,description,audio_url,cover_url,duration_seconds,'
            'file_size_bytes,published_at,reciters(name),surahs(number,name_fr,name_ar)')
        .eq('is_published', true)
        .order('published_at', ascending: false);
    return (rows as List)
        .map((e) => _map(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  static Recitation _map(Map<String, dynamic> m) {
    final reciterMap = m['reciters'];
    final surahMap = m['surahs'];
    final reciter = reciterMap is Map ? reciterMap['name'] as String? : null;
    final surahFr = surahMap is Map ? surahMap['name_fr'] as String? : null;
    final surahAr = surahMap is Map ? surahMap['name_ar'] as String? : null;
    return Recitation(
      id: m['id'] as String,
      title: m['title'] as String,
      reciter: reciter ?? 'Récitateur inconnu',
      surah: surahFr ?? '',
      surahAr: surahAr,
      description: (m['description'] as String?) ?? '',
      source: RecitationSource.remote,
      remoteUrl: m['audio_url'] as String,
      coverUrl: m['cover_url'] as String?,
      durationSeconds: (m['duration_seconds'] as num?)?.toInt(),
      sizeBytes: (m['file_size_bytes'] as num?)?.toInt(),
      addedAt: DateTime.tryParse((m['published_at'] as String?) ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }
}
