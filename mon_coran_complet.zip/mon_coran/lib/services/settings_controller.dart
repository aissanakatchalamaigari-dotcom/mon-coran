import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsController extends ChangeNotifier {
  bool repeatDefault = false;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    repeatDefault = prefs.getBool('repeat_default') ?? false;
  }

  Future<void> setRepeatDefault(bool v) async {
    repeatDefault = v;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('repeat_default', v);
  }
}
