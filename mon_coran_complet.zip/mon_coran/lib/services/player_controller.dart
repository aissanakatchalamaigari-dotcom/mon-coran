import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:permission_handler/permission_handler.dart';

import '../models/recitation.dart';
import 'settings_controller.dart';

class PlayerController extends ChangeNotifier {
  final SettingsController _settings;
  final AudioPlayer player = AudioPlayer();
  final List<StreamSubscription<dynamic>> _subs = [];

  List<Recitation> _queue = [];
  int _index = -1;
  bool repeat = false;
  String? error;
  Timer? _sleepTimer;
  DateTime? sleepEndsAt;
  bool _askedNotifications = false;

  PlayerController(this._settings) {
    repeat = _settings.repeatDefault;
    _subs.add(player.currentIndexStream.listen((i) {
      if (i != null && i != _index && i < _queue.length) {
        _index = i;
        notifyListeners();
      }
    }));
    _subs.add(player.playbackEventStream.listen((_) {}, onError: (Object e, StackTrace st) {
      error = _describe(e);
      notifyListeners();
    }));
    _subs.add(player.playerStateStream.listen((s) {
      if (s.processingState == ProcessingState.completed && _queue.isNotEmpty) {
        player.pause();
        player.seek(Duration.zero, index: _queue.length - 1);
      }
    }));
  }

  Recitation? get current =>
      (_index >= 0 && _index < _queue.length) ? _queue[_index] : null;
  bool get hasNext => _index >= 0 && _index < _queue.length - 1;
  bool get hasPrevious => _index > 0;

  AudioSource _sourceFor(Recitation r) {
    final tag = MediaItem(
      id: r.id,
      title: r.title,
      artist: r.reciter,
      album: r.surah.isEmpty ? null : r.surah,
      artUri: r.coverUrl == null ? null : Uri.tryParse(r.coverUrl!),
      duration: r.durationSeconds == null
          ? null
          : Duration(seconds: r.durationSeconds!),
    );
    final path = r.localPath;
    if (path != null) return AudioSource.file(path, tag: tag);
    return AudioSource.uri(Uri.parse(r.remoteUrl!), tag: tag);
  }

  Future<void> playQueue(List<Recitation> queue, int index) async {
    if (queue.isEmpty || index < 0 || index >= queue.length) return;
    _queue = List.of(queue);
    _index = index;
    error = null;
    notifyListeners();
    unawaited(_askNotificationPermission());
    try {
      final target = _queue[index];
      if (target.localPath != null && !await File(target.localPath!).exists()) {
        throw 'fichier introuvable sur l\'appareil';
      }
      if (target.localPath == null && target.remoteUrl == null) {
        throw 'aucune source audio';
      }
      await player.setAudioSource(
        ConcatenatingAudioSource(children: _queue.map(_sourceFor).toList()),
        initialIndex: index,
        initialPosition: Duration.zero,
      );
      await player.setLoopMode(repeat ? LoopMode.one : LoopMode.off);
      unawaited(player.play());
    } catch (e) {
      error = _describe(e);
      notifyListeners();
    }
  }

  String _describe(Object e) {
    final r = current;
    if (r != null && r.isRemote && !r.isOffline) {
      return 'Lecture impossible. Vérifiez votre connexion ou téléchargez la récitation.';
    }
    if (e is PlayerException) return 'Erreur audio : ${e.message}';
    return 'Lecture impossible : $e';
  }

  Future<void> _askNotificationPermission() async {
    if (_askedNotifications || !Platform.isAndroid) return;
    _askedNotifications = true;
    try {
      if (await Permission.notification.isDenied) {
        await Permission.notification.request();
      }
    } catch (_) {}
  }

  Future<void> togglePlay() async {
    if (current == null) return;
    if (player.playing) {
      await player.pause();
    } else {
      if (player.processingState == ProcessingState.completed) {
        await player.seek(Duration.zero);
      }
      unawaited(player.play());
    }
  }

  Future<void> next() async {
    if (hasNext) await player.seek(Duration.zero, index: _index + 1);
  }

  Future<void> previous() async {
    if (player.position > const Duration(seconds: 3) || !hasPrevious) {
      await player.seek(Duration.zero);
    } else {
      await player.seek(Duration.zero, index: _index - 1);
    }
  }

  Future<void> toggleRepeat() async {
    repeat = !repeat;
    await player.setLoopMode(repeat ? LoopMode.one : LoopMode.off);
    notifyListeners();
  }

  void setSleepTimer(Duration? d) {
    _sleepTimer?.cancel();
    if (d == null) {
      sleepEndsAt = null;
    } else {
      sleepEndsAt = DateTime.now().add(d);
      _sleepTimer = Timer(d, () {
        player.pause();
        sleepEndsAt = null;
        notifyListeners();
      });
    }
    notifyListeners();
  }

  Future<void> stop() async {
    _sleepTimer?.cancel();
    sleepEndsAt = null;
    await player.stop();
    _queue = [];
    _index = -1;
    error = null;
    notifyListeners();
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    _sleepTimer?.cancel();
    player.dispose();
    super.dispose();
  }
}
