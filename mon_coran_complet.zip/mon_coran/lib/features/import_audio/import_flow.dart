import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../services/library_controller.dart';

class _ImportData {
  final String title, reciter, surah, description;
  _ImportData(this.title, this.reciter, this.surah, this.description);
}

/// Sélectionne un fichier audio, demande les métadonnées, puis l'importe.
Future<void> startImport(BuildContext context) async {
  final library = context.read<LibraryController>();
  final messenger = ScaffoldMessenger.of(context);

  FilePickerResult? result;
  try {
    result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3', 'm4a', 'aac', 'ogg', 'wav'],
    );
  } catch (e) {
    messenger.showSnackBar(SnackBar(content: Text('Sélection impossible : $e')));
    return;
  }
  if (result == null || result.files.isEmpty) return;
  final file = result.files.first;
  if (file.path == null) {
    messenger.showSnackBar(const SnackBar(content: Text('Fichier inaccessible.')));
    return;
  }
  if (!context.mounted) return;

  final dot = file.name.lastIndexOf('.');
  final guess = dot > 0 ? file.name.substring(0, dot) : file.name;

  final data = await showModalBottomSheet<_ImportData>(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.surface,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (_) => _ImportForm(initialTitle: guess),
  );
  if (data == null) return;

  try {
    await library.importFile(
      sourcePath: file.path!,
      originalName: file.name,
      title: data.title,
      reciter: data.reciter,
      surah: data.surah,
      description: data.description,
    );
    messenger.showSnackBar(const SnackBar(content: Text('Récitation importée.')));
  } catch (e) {
    messenger.showSnackBar(SnackBar(content: Text('Échec de l\'import : $e')));
  }
}

class _ImportForm extends StatefulWidget {
  final String initialTitle;
  const _ImportForm({required this.initialTitle});

  @override
  State<_ImportForm> createState() => _ImportFormState();
}

class _ImportFormState extends State<_ImportForm> {
  final _key = GlobalKey<FormState>();
  late final _title = TextEditingController(text: widget.initialTitle);
  final _reciter = TextEditingController();
  final _surah = TextEditingController();
  final _desc = TextEditingController();

  @override
  void dispose() {
    _title.dispose();
    _reciter.dispose();
    _surah.dispose();
    _desc.dispose();
    super.dispose();
  }

  String? _required(String? v) =>
      (v == null || v.trim().isEmpty) ? 'Champ requis' : null;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
          20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Form(
          key: _key,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('Informations de la récitation',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              TextFormField(
                  controller: _title,
                  validator: _required,
                  decoration: const InputDecoration(labelText: 'Titre')),
              const SizedBox(height: 12),
              TextFormField(
                  controller: _reciter,
                  validator: _required,
                  decoration: const InputDecoration(labelText: 'Récitateur')),
              const SizedBox(height: 12),
              TextFormField(
                  controller: _surah,
                  validator: _required,
                  decoration: const InputDecoration(labelText: 'Sourate')),
              const SizedBox(height: 12),
              TextFormField(
                  controller: _desc,
                  maxLines: 2,
                  decoration: const InputDecoration(
                      labelText: 'Description (facultatif)')),
              const SizedBox(height: 18),
              FilledButton(
                onPressed: () {
                  if (_key.currentState!.validate()) {
                    Navigator.of(context).pop(_ImportData(
                        _title.text.trim(),
                        _reciter.text.trim(),
                        _surah.text.trim(),
                        _desc.text.trim()));
                  }
                },
                child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Text('Importer')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
