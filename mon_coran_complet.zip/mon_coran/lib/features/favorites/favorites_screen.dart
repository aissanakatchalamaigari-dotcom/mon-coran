import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/widgets/empty_state.dart';
import '../../core/widgets/recitation_actions.dart';
import '../../core/widgets/recitation_tile.dart';
import '../../models/recitation.dart';
import '../../services/favorites_controller.dart';
import '../../services/library_controller.dart';
import '../../services/player_controller.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final lib = context.watch<LibraryController>();
    final fav = context.watch<FavoritesController>();
    final byId = {for (final r in lib.items) r.id: r};
    final list = fav.ids.reversed
        .map((id) => byId[id])
        .whereType<Recitation>()
        .toList();

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Favoris',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              const SizedBox(height: 14),
              Expanded(
                child: list.isEmpty
                    ? EmptyState(
                        icon: Icons.favorite_border_rounded,
                        title: 'Aucun favori',
                        message:
                            'Appuyez sur le cœur d\'une récitation pour la retrouver ici.',
                        actionLabel: 'Parcourir la bibliothèque',
                        onAction: () => context.go('/library'),
                      )
                    : ListView.builder(
                        itemCount: list.length,
                        itemBuilder: (_, i) => RecitationTile(
                          recitation: list[i],
                          onTap: () async {
                            await context
                                .read<PlayerController>()
                                .playQueue(list, i);
                            if (context.mounted) context.push('/player');
                          },
                          trailing: RecitationActions(
                            r: list[i],
                            onDeleteLocal: () => lib.removeLocal(list[i].id),
                          ),
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
