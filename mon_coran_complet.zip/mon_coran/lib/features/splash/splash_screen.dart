import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/glow_background.dart';
import '../../core/widgets/star_painter.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1600))
    ..forward();
  late final Animation<double> _a =
      CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 2300), () {
      if (mounted) context.go('/');
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GlowBackground(
        child: Center(
          child: FadeTransition(
            opacity: _a,
            child: ScaleTransition(
              scale: Tween<double>(begin: 0.85, end: 1.0).animate(_a),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 130,
                    height: 130,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const RadialGradient(
                          colors: [Color(0xFF3B2E8F), AppColors.surface]),
                      boxShadow: [
                        BoxShadow(
                            color: AppColors.violet.withAlpha(120),
                            blurRadius: 50),
                      ],
                    ),
                    child: const CustomPaint(painter: StarPainter()),
                  ),
                  const SizedBox(height: 28),
                  const Text('Mon Coran',
                      style: TextStyle(
                          fontSize: 34,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1)),
                  const SizedBox(height: 6),
                  const Text('Écoutez. Apprenez. Méditez.',
                      style: TextStyle(color: AppColors.lavender)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
