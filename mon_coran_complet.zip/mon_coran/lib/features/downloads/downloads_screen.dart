import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/format.dart';
import '../../core/widgets/empty_state.dart';
import '../../models/recitation.dart';
import '../../services/library_controller.dart';
import '../../services/player_controller.dart';

class DownloadsScreen extends StatelessWidget {
  const DownloadsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final lib = context.watch<LibraryController>();
    final byId = {for (final r in lib.items) r.id: r};
    final active = lib.activeDownloadIds
        .map((id) => byId[id])
        .whereType<Recitation>()
        .toList();
    final done = lib.downloadedItems;
    final failed = lib.downloadErrors.entries
        .where((e) => byId[e.key] != null)
        .toList();
    final empty = active.isEmpty && done.isEmpty && failed.isEmpty;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Téléchargements',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              if (done.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                      '${done.length} fichier(s) • ${formatBytes(lib.downloadsBytes)} • disponibles hors ligne',
                      style: const TextStyle(color: AppColors.lavender)),
                ),
              const SizedBox(height: 14),
              Expanded(
                child: empty
                    ? EmptyState(
                        icon: Icons.download_for_offline_rounded,
                        title: 'Aucun téléchargement',
                        message:
                            'Téléchargez des récitations en ligne depuis la bibliothèque pour les écouter sans connexion.',
                        actionLabel: 'Ouvrir la bibliothèque',
                        onAction: () => context.go('/library'),
                      )
                    : ListView(
                        children: [
                          for (final r in active)
                            _Card(
                              title: r.title,
                              subtitle:
                                  'Téléchargement… ${((lib.progressOf(r.id) ?? 0) * 100).round()} %',
                              progress: lib.progressOf(r.id),
                              trailing: IconButton(
                                icon: const Icon(Icons.close_rounded),
                                onPressed: () => lib.cancelDownload(r.id),
                              ),
                            ),
                          for (final e in failed)
                            _Card(
                              title: byId[e.key]!.title,
                              subtitle: e.value,
                              error: true,
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.refresh_rounded),
                                    onPressed: () => lib.download(byId[e.key]!),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.close_rounded),
                                    onPressed: () => lib.clearDownloadError(e.key),
                                  ),
                                ],
                              ),
                            ),
                          for (var i = 0; i < done.length; i++)
                            _Card(
                              title: done[i].title,
                              subtitle:
                                  '${done[i].reciter} • ${formatBytes(lib.sizeOf(done[i].id))} • Hors ligne',
                              onTap: () async {
                                await context
                                    .read<PlayerController>()
                                    .playQueue(done, i);
                                if (context.mounted) context.push('/player');
                              },
                              trailing: IconButton(
                                tooltip: 'Supprimer',
                                icon: const Icon(Icons.delete_outline_rounded,
                                    color: AppColors.lavender),
                                onPressed: () => lib.deleteDownload(done[i].id),
                              ),
                            ),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final String title, subtitle;
  final double? progress;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool error;
  const _Card(
      {required this.title,
      required this.subtitle,
      this.progress,
      this.trailing,
      this.onTap,
      this.error = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 15)),
                      const SizedBox(height: 3),
                      Text(subtitle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 12.5,
                              color: error
                                  ? const Color(0xFFFF8A9B)
                                  : AppColors.lavender)),
                      if (progress != null) ...[
                        const SizedBox(height: 8),
                        LinearProgressIndicator(
                            value: progress! > 0 ? progress : null),
                      ],
                    ],
                  ),
                ),
                if (trailing != null) trailing!,
              ],
            ),
          ),
        ),
      ),
    );
  }
}
