import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/empty_state.dart';
import '../../core/widgets/recitation_actions.dart';
import '../../core/widgets/recitation_tile.dart';
import '../../models/recitation.dart';
import '../../services/favorites_controller.dart';
import '../../services/library_controller.dart';
import '../../services/player_controller.dart';
import '../../services/remote_service.dart';
import '../import_audio/import_flow.dart';

const _recommendedSurahs = [
  'Al-Fatiha',
  'Al-Kahf',
  'Ya-Sin',
  'Ar-Rahman',
  'Al-Mulk',
  'Al-Ikhlas',
];

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final lib = context.watch<LibraryController>();
    final fav = context.watch<FavoritesController>();
    final items = lib.items;

    Future<void> play(List<Recitation> list, int index) async {
      await context.read<PlayerController>().playQueue(list, index);
      if (context.mounted) context.push('/player');
    }

    void openLibraryWith(String q) {
      lib.setQuery(q);
      context.go('/library');
    }

    final counts = <String, int>{};
    for (final r in items) {
      counts[r.reciter] = (counts[r.reciter] ?? 0) + 1;
    }
    final popular = counts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final byId = {for (final r in items) r.id: r};
    final recentFavs = fav.ids.reversed
        .map((id) => byId[id])
        .whereType<Recitation>()
        .take(3)
        .toList();

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: lib.loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: lib.sync,
                child: ListView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                  children: [
                    const Text('السلام عليكم',
                        style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.w700,
                            color: AppColors.lavender)),
                    const SizedBox(height: 4),
                    const Text('Bienvenue sur Mon Coran',
                        style: TextStyle(
                            fontSize: 22, fontWeight: FontWeight.w800)),
                    if (lib.syncing)
                      const Padding(
                        padding: EdgeInsets.only(top: 12),
                        child: LinearProgressIndicator(),
                      ),
                    if (lib.syncError != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: Text(lib.syncError!,
                            style: const TextStyle(color: Color(0xFFFF8A9B))),
                      ),
                    const SizedBox(height: 22),
                    if (items.isEmpty)
                      SizedBox(
                        height: 380,
                        child: EmptyState(
                          icon: Icons.library_music_rounded,
                          title: 'Aucune récitation pour le moment',
                          message: RemoteService.enabled
                              ? 'Aucune récitation publiée en ligne. Tirez pour actualiser ou importez un MP3.'
                              : 'Importez un fichier MP3 depuis votre téléphone pour commencer l\'écoute.',
                          actionLabel: 'Importer un MP3',
                          onAction: () => startImport(context),
                          secondaryLabel:
                              RemoteService.enabled ? 'Actualiser' : null,
                          onSecondary: RemoteService.enabled ? lib.sync : null,
                        ),
                      )
                    else ...[
                      _Featured(
                          title: items.first.title,
                          subtitle: items.first.subtitle,
                          onPlay: () => play(items, 0)),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () => context.go('/library'),
                          icon: const Icon(Icons.library_music_rounded),
                          label: const Text('Ouvrir la bibliothèque'),
                        ),
                      ),
                      if (popular.isNotEmpty) ...[
                        const _Section('Récitants populaires'),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            for (final e in popular.take(6))
                              ActionChip(
                                avatar: const Icon(Icons.person_rounded,
                                    size: 16, color: AppColors.violet),
                                label: Text(e.key),
                                backgroundColor: AppColors.surface,
                                onPressed: () => openLibraryWith(e.key),
                              ),
                          ],
                        ),
                      ],
                      const _Section('Sourates recommandées'),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final s in _recommendedSurahs)
                            ActionChip(
                              label: Text(s),
                              backgroundColor: AppColors.surface,
                              onPressed: () => openLibraryWith(s),
                            ),
                        ],
                      ),
                      if (recentFavs.isNotEmpty) ...[
                        const _Section('Favoris récents'),
                        for (var i = 0; i < recentFavs.length; i++)
                          RecitationTile(
                            recitation: recentFavs[i],
                            onTap: () => play(recentFavs, i),
                            trailing: RecitationActions(r: recentFavs[i]),
                          ),
                      ],
                      const _Section('Dernières récitations'),
                      for (var i = 0; i < items.length && i < 5; i++)
                        RecitationTile(
                          recitation: items[i],
                          onTap: () => play(items, i),
                          trailing: RecitationActions(
                            r: items[i],
                            onDeleteLocal: () => lib.removeLocal(items[i].id),
                          ),
                        ),
                    ],
                  ],
                ),
              ),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  const _Section(this.title);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 26, bottom: 12),
        child: Text(title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      );
}

class _Featured extends StatelessWidget {
  final String title, subtitle;
  final VoidCallback onPlay;
  const _Featured(
      {required this.title, required this.subtitle, required this.onPlay});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF4A3AA8), AppColors.surface],
        ),
        border: Border.all(color: AppColors.violet.withAlpha(110)),
        boxShadow: [
          BoxShadow(color: AppColors.violet.withAlpha(60), blurRadius: 28),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('RÉCITATION À L\'HONNEUR',
              style: TextStyle(
                  letterSpacing: 1.4,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: AppColors.lavender)),
          const SizedBox(height: 10),
          Text(title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: AppColors.lavender)),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: onPlay,
            icon: const Icon(Icons.play_arrow_rounded),
            label: const Text('Écouter'),
          ),
        ],
      ),
    );
  }
}
