import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/format.dart';
import '../../core/widgets/glow_background.dart';
import '../../core/widgets/star_painter.dart';
import '../../core/widgets/waveform.dart';
import '../../models/recitation.dart';
import '../../services/favorites_controller.dart';
import '../../services/player_controller.dart';

class PlayerScreen extends StatelessWidget {
  const PlayerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final pc = context.watch<PlayerController>();
    final fav = context.watch<FavoritesController>();
    final r = pc.current;
    final size = MediaQuery.of(context).size;
    final art = math.min(size.width * 0.66, size.height * 0.3);

    return Scaffold(
      body: GlowBackground(
        child: SafeArea(
          child: r == null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('Aucune lecture en cours'),
                      const SizedBox(height: 12),
                      FilledButton(
                          onPressed: () => context.pop(),
                          child: const Text('Retour')),
                    ],
                  ),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          IconButton(
                            onPressed: () => context.pop(),
                            icon: const Icon(Icons.keyboard_arrow_down_rounded),
                            iconSize: 34,
                          ),
                          const Spacer(),
                          IconButton(
                            onPressed: () => fav.toggle(r.id),
                            iconSize: 28,
                            color: fav.isFavorite(r.id)
                                ? AppColors.violet
                                : AppColors.lavender,
                            icon: Icon(fav.isFavorite(r.id)
                                ? Icons.favorite_rounded
                                : Icons.favorite_border_rounded),
                          ),
                        ],
                      ),
                      SizedBox(height: size.height * 0.01),
                      _Artwork(size: art, r: r),
                      const SizedBox(height: 26),
                      Text(r.title,
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 24, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 6),
                      Text(r.subtitle,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: AppColors.lavender)),
                      const SizedBox(height: 20),
                      StreamBuilder<bool>(
                        stream: pc.player.playingStream,
                        builder: (_, snap) =>
                            Waveform(active: snap.data ?? false),
                      ),
                      const SizedBox(height: 10),
                      _SeekBar(player: pc.player),
                      if (pc.error != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text(pc.error!,
                              textAlign: TextAlign.center,
                              style: const TextStyle(color: Color(0xFFFF8A9B))),
                        ),
                      const SizedBox(height: 14),
                      _Controls(pc: pc),
                      if (pc.sleepEndsAt != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 12),
                          child: Text(
                              'Arrêt automatique à ${TimeOfDay.fromDateTime(pc.sleepEndsAt!).format(context)}',
                              style: const TextStyle(
                                  color: AppColors.lavender, fontSize: 12.5)),
                        ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}

void _showSleepSheet(BuildContext context, PlayerController pc) {
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppColors.surface,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (ctx) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Minuterie de sommeil',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          ),
          for (final m in const [15, 30, 45, 60])
            ListTile(
              leading: const Icon(Icons.bedtime_rounded, color: AppColors.violet),
              title: Text('$m minutes'),
              onTap: () {
                pc.setSleepTimer(Duration(minutes: m));
                Navigator.pop(ctx);
              },
            ),
          ListTile(
            leading: const Icon(Icons.timer_off_rounded, color: AppColors.lavender),
            title: const Text('Désactiver'),
            onTap: () {
              pc.setSleepTimer(null);
              Navigator.pop(ctx);
            },
          ),
          const SizedBox(height: 8),
        ],
      ),
    ),
  );
}

class _Controls extends StatelessWidget {
  final PlayerController pc;
  const _Controls({required this.pc});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        IconButton(
          onPressed: pc.toggleRepeat,
          iconSize: 28,
          color: pc.repeat ? AppColors.violet : AppColors.lavender.withAlpha(150),
          icon: Icon(pc.repeat ? Icons.repeat_one_rounded : Icons.repeat_rounded),
          tooltip: 'Répéter',
        ),
        IconButton(
          onPressed: pc.previous,
          iconSize: 40,
          icon: const Icon(Icons.skip_previous_rounded),
        ),
        StreamBuilder<PlayerState>(
          stream: pc.player.playerStateStream,
          builder: (_, snap) {
            final st = snap.data;
            final playing = st?.playing ?? false;
            final busy = st?.processingState == ProcessingState.loading ||
                st?.processingState == ProcessingState.buffering;
            return GestureDetector(
              onTap: pc.togglePlay,
              child: Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                      colors: [AppColors.lavender, AppColors.violet]),
                  boxShadow: [
                    BoxShadow(
                        color: AppColors.violet.withAlpha(120), blurRadius: 24),
                  ],
                ),
                child: busy
                    ? const Padding(
                        padding: EdgeInsets.all(22),
                        child: CircularProgressIndicator(
                            strokeWidth: 3, color: AppColors.night))
                    : Icon(
                        playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                        size: 44,
                        color: AppColors.night),
              ),
            );
          },
        ),
        IconButton(
          onPressed: pc.hasNext ? pc.next : null,
          iconSize: 40,
          icon: const Icon(Icons.skip_next_rounded),
        ),
        IconButton(
          onPressed: () => _showSleepSheet(context, pc),
          iconSize: 28,
          tooltip: 'Minuterie de sommeil',
          color: pc.sleepEndsAt != null
              ? AppColors.violet
              : AppColors.lavender.withAlpha(150),
          icon: const Icon(Icons.bedtime_outlined),
        ),
      ],
    );
  }
}

class _SeekBar extends StatefulWidget {
  final AudioPlayer player;
  const _SeekBar({required this.player});

  @override
  State<_SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<_SeekBar> {
  double? _drag;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration?>(
      stream: widget.player.durationStream,
      builder: (_, dSnap) {
        final total = dSnap.data ?? Duration.zero;
        final maxV =
            total.inMilliseconds > 0 ? total.inMilliseconds.toDouble() : 1.0;
        return StreamBuilder<Duration>(
          stream: widget.player.positionStream,
          builder: (_, pSnap) {
            final pos = pSnap.data ?? Duration.zero;
            final value =
                (_drag ?? pos.inMilliseconds.toDouble()).clamp(0.0, maxV);
            return Column(
              children: [
                Slider(
                  value: value.toDouble(),
                  max: maxV,
                  onChanged: total == Duration.zero
                      ? null
                      : (v) => setState(() => _drag = v),
                  onChangeEnd: (v) {
                    widget.player.seek(Duration(milliseconds: v.round()));
                    setState(() => _drag = null);
                  },
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(formatDuration(Duration(milliseconds: value.round())),
                          style: const TextStyle(
                              color: AppColors.lavender, fontSize: 12)),
                      Text(formatDuration(total),
                          style: const TextStyle(
                              color: AppColors.lavender, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class _Artwork extends StatelessWidget {
  final double size;
  final Recitation r;
  const _Artwork({required this.size, required this.r});

  @override
  Widget build(BuildContext context) {
    const star = CustomPaint(painter: StarPainter());
    final cover = r.coverUrl;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const RadialGradient(
            colors: [Color(0xFF3B2E8F), AppColors.surface]),
        border: Border.all(color: AppColors.violet.withAlpha(120), width: 1.5),
        boxShadow: [
          BoxShadow(color: AppColors.violet.withAlpha(90), blurRadius: 40),
        ],
      ),
      child: cover == null
          ? star
          : ClipOval(
              child: Image.network(
                cover,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => star,
              ),
            ),
    );
  }
}
