import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/format.dart';
import '../../services/library_controller.dart';
import '../../services/player_controller.dart';
import '../../services/remote_service.dart';
import '../../services/settings_controller.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<bool> _confirm(BuildContext context, String title, String msg) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text(title),
        content: Text(msg),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Annuler')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Confirmer')),
        ],
      ),
    );
    return ok == true;
  }

  @override
  Widget build(BuildContext context) {
    final lib = context.watch<LibraryController>();
    final settings = context.watch<SettingsController>();

    String syncText;
    if (!RemoteService.enabled) {
      syncText = 'Non configurée (voir README)';
    } else if (lib.syncing) {
      syncText = 'En cours…';
    } else if (lib.lastSync != null) {
      final d = lib.lastSync!;
      syncText =
          'Dernière : ${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')} '
          '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    } else {
      syncText = 'Jamais synchronisé';
    }

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          children: [
            const Text('Paramètres',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            const SizedBox(height: 18),
            const _Title('Lecture'),
            _Card(
              child: SwitchListTile(
                secondary:
                    const Icon(Icons.repeat_one_rounded, color: AppColors.violet),
                title: const Text('Répéter par défaut'),
                subtitle: const Text('Appliqué au prochain lancement de lecture'),
                value: settings.repeatDefault,
                onChanged: settings.setRepeatDefault,
              ),
            ),
            const _Title('Synchronisation'),
            _Card(
              child: ListTile(
                leading: const Icon(Icons.cloud_sync_rounded,
                    color: AppColors.violet),
                title: const Text('Récitations en ligne'),
                subtitle: Text(syncText),
                trailing: RemoteService.enabled
                    ? IconButton(
                        icon: const Icon(Icons.sync_rounded),
                        onPressed: lib.syncing ? null : lib.sync,
                      )
                    : null,
              ),
            ),
            const _Title('Stockage'),
            _Card(
              child: ListTile(
                leading: const Icon(Icons.download_done_rounded,
                    color: AppColors.violet),
                title: const Text('Téléchargements'),
                subtitle: Text(formatBytes(lib.downloadsBytes)),
                trailing: TextButton(
                  onPressed: lib.downloadsBytes == 0
                      ? null
                      : () async {
                          if (await _confirm(context, 'Vider les téléchargements ?',
                              'Les fichiers téléchargés seront supprimés de cet appareil.')) {
                            await lib.clearDownloads();
                          }
                        },
                  child: const Text('Vider'),
                ),
              ),
            ),
            const SizedBox(height: 10),
            _Card(
              child: FutureBuilder<int>(
                future: lib.importedBytes(),
                builder: (context, snap) => ListTile(
                  leading: const Icon(Icons.phone_android_rounded,
                      color: AppColors.violet),
                  title: const Text('Fichiers importés'),
                  subtitle: Text(formatBytes(snap.data ?? 0)),
                  trailing: TextButton(
                    onPressed: (snap.data ?? 0) == 0
                        ? null
                        : () async {
                            final player = context.read<PlayerController>();
                            if (await _confirm(context, 'Supprimer les imports ?',
                                'Les fichiers importés seront effacés de cet appareil.')) {
                              await player.stop();
                              await lib.clearLocal();
                            }
                          },
                    child: const Text('Vider'),
                  ),
                ),
              ),
            ),
            const _Title('À propos'),
            const _Card(
              child: ListTile(
                leading: Icon(Icons.info_outline_rounded, color: AppColors.violet),
                title: Text('Mon Coran'),
                subtitle: Text('Version 1.0.0'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Title extends StatelessWidget {
  final String t;
  const _Title(this.t);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 22, bottom: 10),
        child: Text(t,
            style: const TextStyle(
                fontSize: 13,
                letterSpacing: 1.2,
                fontWeight: FontWeight.w700,
                color: AppColors.lavender)),
      );
}

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});
  @override
  Widget build(BuildContext context) => Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        clipBehavior: Clip.antiAlias,
        child: child,
      );
}
