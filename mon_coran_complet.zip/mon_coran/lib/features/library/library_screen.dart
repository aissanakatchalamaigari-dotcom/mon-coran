import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/empty_state.dart';
import '../../core/widgets/recitation_actions.dart';
import '../../core/widgets/recitation_tile.dart';
import '../../models/recitation.dart';
import '../../services/library_controller.dart';
import '../../services/player_controller.dart';
import '../../services/remote_service.dart';
import '../import_audio/import_flow.dart';

enum _Filter { all, offline, imported, online }

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  final _ctrl = TextEditingController();
  _Filter _filter = _Filter.all;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  bool _matches(Recitation r, String q) {
    switch (_filter) {
      case _Filter.all:
        break;
      case _Filter.offline:
        if (!r.isOffline) return false;
      case _Filter.imported:
        if (r.isRemote) return false;
      case _Filter.online:
        if (!r.isRemote) return false;
    }
    if (q.isEmpty) return true;
    return r.title.toLowerCase().contains(q) ||
        r.reciter.toLowerCase().contains(q) ||
        r.surah.toLowerCase().contains(q) ||
        (r.surahAr ?? '').contains(q);
  }

  Future<bool> _confirm(String title, String msg) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text(title),
        content: Text(msg),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Annuler')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Supprimer')),
        ],
      ),
    );
    return ok == true;
  }

  @override
  Widget build(BuildContext context) {
    final lib = context.watch<LibraryController>();

    // Synchronise le champ de recherche si la requête est posée depuis l'accueil.
    if (_ctrl.text != lib.query) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _ctrl.text != lib.query) {
          _ctrl.value = TextEditingValue(
              text: lib.query,
              selection: TextSelection.collapsed(offset: lib.query.length));
        }
      });
    }

    final all = lib.items;
    final q = lib.query.trim().toLowerCase();
    final filtered = all.where((r) => _matches(r, q)).toList();

    Future<void> play(int i) async {
      await context.read<PlayerController>().playQueue(filtered, i);
      if (mounted) context.push('/player');
    }

    Future<void> deleteLocal(Recitation r) async {
      final player = context.read<PlayerController>();
      if (!await _confirm('Supprimer ?', '« ${r.title} » sera supprimée de cet appareil.')) {
        return;
      }
      if (player.current?.id == r.id) await player.stop();
      await lib.removeLocal(r.id);
    }

    Widget body;
    if (lib.loading) {
      body = const Center(child: CircularProgressIndicator());
    } else if (all.isEmpty) {
      body = EmptyState(
        icon: Icons.audio_file_rounded,
        title: 'Bibliothèque vide',
        message: RemoteService.enabled
            ? 'Aucune récitation en ligne pour le moment. Importez un MP3 ou actualisez.'
            : 'Importez vos fichiers MP3 pour les retrouver ici, même sans connexion.',
        actionLabel: 'Importer un MP3',
        onAction: () => startImport(context),
      );
    } else if (filtered.isEmpty) {
      body = const EmptyState(
        icon: Icons.search_off_rounded,
        title: 'Aucun résultat',
        message: 'Essayez avec un autre mot-clé ou un autre filtre.',
      );
    } else {
      body = RefreshIndicator(
        onRefresh: lib.sync,
        child: ListView.builder(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.only(bottom: 90),
          itemCount: filtered.length,
          itemBuilder: (_, i) => RecitationTile(
            recitation: filtered[i],
            onTap: () => play(i),
            trailing: RecitationActions(
              r: filtered[i],
              onDeleteLocal: () => deleteLocal(filtered[i]),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => startImport(context),
        backgroundColor: AppColors.violet,
        foregroundColor: AppColors.night,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Importer'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text('Bibliothèque',
                        style: TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w800)),
                  ),
                  if (RemoteService.enabled)
                    IconButton(
                      tooltip: 'Synchroniser',
                      onPressed: lib.syncing ? null : lib.sync,
                      icon: const Icon(Icons.sync_rounded),
                    ),
                ],
              ),
              if (lib.syncing) const LinearProgressIndicator(),
              if (lib.syncError != null)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(lib.syncError!,
                      style: const TextStyle(color: Color(0xFFFF8A9B))),
                ),
              const SizedBox(height: 10),
              TextField(
                controller: _ctrl,
                onChanged: lib.setQuery,
                decoration: InputDecoration(
                  hintText: 'Rechercher une sourate, un récitateur…',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: lib.query.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () => lib.setQuery(''),
                        ),
                ),
              ),
              const SizedBox(height: 10),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    for (final e in const {
                      _Filter.all: 'Toutes',
                      _Filter.offline: 'Hors ligne',
                      _Filter.imported: 'Importées',
                      _Filter.online: 'En ligne',
                    }.entries)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(e.value),
                          selected: _filter == e.key,
                          onSelected: (_) => setState(() => _filter = e.key),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Expanded(child: body),
            ],
          ),
        ),
      ),
    );
  }
}
