enum RecitationSource { local, remote }

class Recitation {
  final String id;
  final String title;
  final String reciter;
  final String surah;
  final String? surahAr;
  final String description;
  final RecitationSource source;
  final String? localPath; // fichier sur l'appareil (import ou téléchargement)
  final String? remoteUrl; // URL Supabase Storage
  final String? coverUrl;
  final int? durationSeconds;
  final int? sizeBytes;
  final DateTime addedAt;

  const Recitation({
    required this.id,
    required this.title,
    required this.reciter,
    required this.surah,
    this.surahAr,
    required this.description,
    required this.source,
    this.localPath,
    this.remoteUrl,
    this.coverUrl,
    this.durationSeconds,
    this.sizeBytes,
    required this.addedAt,
  });

  bool get isRemote => source == RecitationSource.remote;
  bool get isOffline => localPath != null;
  String get subtitle => surah.isEmpty ? reciter : '$reciter • $surah';

  Recitation copyWith({String? localPath}) => Recitation(
        id: id,
        title: title,
        reciter: reciter,
        surah: surah,
        surahAr: surahAr,
        description: description,
        source: source,
        localPath: localPath ?? this.localPath,
        remoteUrl: remoteUrl,
        coverUrl: coverUrl,
        durationSeconds: durationSeconds,
        sizeBytes: sizeBytes,
        addedAt: addedAt,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'reciter': reciter,
        'surah': surah,
        'surahAr': surahAr,
        'description': description,
        'source': source.name,
        'localPath': localPath,
        'remoteUrl': remoteUrl,
        'coverUrl': coverUrl,
        'durationSeconds': durationSeconds,
        'sizeBytes': sizeBytes,
        'addedAt': addedAt.toIso8601String(),
      };

  factory Recitation.fromJson(Map<String, dynamic> j) => Recitation(
        id: j['id'] as String,
        title: j['title'] as String,
        reciter: j['reciter'] as String,
        surah: (j['surah'] as String?) ?? '',
        surahAr: j['surahAr'] as String?,
        description: (j['description'] as String?) ?? '',
        source: RecitationSource.values
            .byName((j['source'] as String?) ?? 'local'),
        localPath: j['localPath'] as String?,
        remoteUrl: j['remoteUrl'] as String?,
        coverUrl: j['coverUrl'] as String?,
        durationSeconds: (j['durationSeconds'] as num?)?.toInt(),
        sizeBytes: (j['sizeBytes'] as num?)?.toInt(),
        addedAt: DateTime.tryParse((j['addedAt'] as String?) ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0),
      );
}
